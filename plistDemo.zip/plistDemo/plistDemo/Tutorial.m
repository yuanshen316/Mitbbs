//
//  Tutorial.m
//  plistDemo
//
//  Created by Yuan Junsheng on 13-3-6.
//  Copyright (c) 2013年 Yuan Junsheng. All rights reserved.
//

#import "Tutorial.h"

@implementation Tutorial
@synthesize title = _title, url = _url;
@end
