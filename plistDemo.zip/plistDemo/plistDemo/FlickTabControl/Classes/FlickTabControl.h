//
//  FlickTabControl.h
//  FlickTabControl
//
//  Created by Shaun Harrison on 2/11/09.
//  Copyright 2009 enormego. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "FlickTableViewController.h"
#import "FlickTabView.h"