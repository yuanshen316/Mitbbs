//
//  Tutorial.h
//  plistDemo
//
//  Created by Yuan Junsheng on 13-3-6.
//  Copyright (c) 2013年 Yuan Junsheng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Tutorial : NSObject

@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *url;

@end
