//
//  SecondViewController.h
//  plistDemo
//
//  Created by Yuan Junsheng on 13-3-10.
//  Copyright (c) 2013年 Yuan Junsheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController
{
    
}
@property (strong, nonatomic) NSString *newsUrl;
@end
